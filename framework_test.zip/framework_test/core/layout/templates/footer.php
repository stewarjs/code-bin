</main>
<script src="https://code.jquery.com/jquery-3.1.1.min.js"></script>
<script src="https://code.jquery.com/jquery-migrate-3.0.1.js"></script>
<script src="/framework_test/core/framework/js/nfc.framework.js"></script>
<script>
	$('#dd__menu').DropDown();
</script>
</body>
</html>