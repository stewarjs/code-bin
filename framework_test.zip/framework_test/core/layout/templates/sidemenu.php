<nav id="nav" class="menu__container">
   <ul class="menu">
   
   <li class="menu__item"><a href="../../../../framework_home/core/layout/templates/index.php"><svg class="icon" role="presentation"><use xlink:href="#framework_svg_home" /></svg><span class="menu__item__label">Home</span></a></li>
   
   	<li class="menu__item"><a href="../../../../framework_home/core/layout/templates/index.php"><svg class="icon" role="presentation"><use xlink:href="#framework_svg_payment" /></svg><span class="menu__item__label">Transactions</span></a></li>

	<li class="menu__item"><a href="../../../../framework_home/core/layout/templates/expenses.php"><svg class="icon" role="presentation" style="width:35px;height:35px"><use xlink:href="#framework_svg_database" /></svg><span class="menu__item__label">Modules</span></a></li>

	<li class="menu__item"><a href="../../../../framework_home/core/layout/templates/reports.php"><svg class="icon" role="presentation"><use xlink:href="#framework_svg_piechart" /></svg><span class="menu__item__label">Reports</span></a></li>
   

   </ul>

</nav>