<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title><?php print($page->title . ' | ' . $page->app_name); ?></title>
	<meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#0e80a7">

    <link href="/framework_test/core/framework/css/nfc.framework.css" type="text/css" rel="stylesheet">
    <link href="/framework_test/core/framework/css/theme.css" type="text/css" rel="stylesheet">

</head>
<body>
	<a href="#nav" class="skip-content" id="skipheader">Skip to Navigation</a>
    <a href="#main" class="skip-content" id="skipnav">Skip to Main Content</a>
		<header class="header">
    	<h1 class="header__logo align--left">
			<svg class="logo__icon" viewBox="0 0 24 24" role="presentation">
				<path fill="#FBFBFB" d="M17.00354,5H11.99646C10.8938599,5,10,5.8937988,10,6.9963989V18.00354
	C10,19.1061401,10.8938599,20,11.99646,20H17.00354C18.1061401,20,19,19.1061401,19,18.00354V6.9963989
	C19,5.8937988,18.1061401,5,17.00354,5z M14.5,19c-0.6904297,0-1.25-0.4473267-1.25-1c0-0.5527344,0.5595703-1,1.25-1
	c0.6895142,0,1.25,0.4472656,1.25,1C15.75,18.5526733,15.1895142,19,14.5,19z M17,16h-5V7h5V16z M8,16H3V2h12v1h2V2
	c0-1.1010742-0.8994141-2-2-2H3C1.9003906,0,1,0.8989258,1,2v16c0,1.0996094,0.9003906,2,2,2h5.5551758
	C8.2114258,19.4101562,8,18.7338867,8,18.003418V16z"/>
			</svg>
			<span class="logo__text"><?php print($page->app_name); ?></span>
       </h1>
        
           <?php $page->menu('topmenu'); ?>

        </header>
        <?php 
			if(strpos(dirname($_SERVER['PHP_SELF']), 'auth') === false){
				$page->menu('sidemenu');
				echo '<main class="layout--two-column" id="main">';
			}else{
				echo '<main id="main">';
			}
		?>
        