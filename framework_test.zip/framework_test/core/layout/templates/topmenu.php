<div class="header__menu float--right">
           
	<select id="dd__menu" data-update="false">
		<option value="" selected disabled data-svg="framework_svg_menu">Menu</option>
		<option value="help" data-svg="framework_svg_help">Help</option>
		<option value="settings" data-svg="framework_svg_settings">Settings</option>
		<option value="logout" data-href="/apps/training/auth/?login=false" data-svg="framework_svg_logout">Logout</option>
	</select>

</div>