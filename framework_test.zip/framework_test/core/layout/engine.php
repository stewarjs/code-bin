<?php

class page {
	
	private $template_directory = __DIR__.'\\templates\\';
	private $require_login = false;
	public $app_name = 'NFC Framework';
	public $title = '';	
	
	function __construct() {
		/*session_start();
		if($this->require_login === true && !isset($_SESSION['active']) && !isset($_REQUEST['login'])) {
			
			header('Location: /apps/management/auth/?page='.$_SERVER['PHP_SELF'].'&login');
			
		}*/
		
	}

	public function title($text) {
		$this->title = $text;
	}	


	public function header($header_name = null) {
		global $page;
		
		if(isset($header_name)) {
			// Specify header
			if(is_file($this->template_directory . $header_name . '.php')) {
				require($this->template_directory . $header_name . '.php');
			}
		}else{
			// Render default header
			require($this->template_directory . 'header.php');
		}
		
	}
	
	public function menu($menu_name) {
		if(isset($menu_name)) {
			// Specify header
			if(is_file($this->template_directory . $menu_name . '.php')) {
				require($this->template_directory . $menu_name . '.php');
			}else{
				die('Error: Menu file not found.');
			}
		}else{
			die('Error: Path to menu not specified.');
		}
		
	}


	public function footer($footer_name = null) {
		global $page;
		if(isset($footer_name)) {
			// Specify header
			if(is_file($this->template_directory . $footer_name . '.php')) {
				require($this->template_directory . $footer_name . '.php');
			}
		}else{
			// Render default header
			require($this->template_directory . 'footer.php');
		}
		
	}




}

?>