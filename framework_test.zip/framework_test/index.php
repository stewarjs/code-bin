<?php

require_once('core/layout/engine.php');

$page = new page();

$page->title('Home');

$page->header();


?>

<section>
      	
<h2 class="heading--medium">NFC Framework for Applications</h2>

<p>This framework is provided and maintained by TCB Web. Any questions can be directed to tcb.web@nfc.usda.gov.
Documentation can be found on the OCFO Intranet at [FUTURE LINK].</p>

<h3 class="heading--small">Intended Goals</h3>
<p>It is the intent of this framework to achieve the following:</p>
<ul>
	<li>Provide a 508 compliant, front-end framework for NFC applications.</li>
	<li>Provide a consistent, visual brand across all NFC applications.</li>
	<li>Provide a singular point for front-end bug fixes</li>
	<li>Provide GESD developers with an out-of-the-box front-end framework to facilitate rapid development.</li>
</ul>

<h3 class="heading--small">Versioning</h3>
<p>Given a version number MAJOR.MINOR.PATCH, the process for tracking version changes is as follows:</p>
<ul>
	<li>The MAJOR version will be updated when incompatiable changes are made.</li>
	<li>The MINOR version will be updated when functionality is added in a backwards-compatible manner.</li>
	<li>The PATCH version will be updated when backwards-compatible bug fixes are added to the framework.</li>
</ul>

<p>Once a versioned package has been released, the contents of that version WILL NOT be modified. Any modifications will be released as a new version.</p>
	
<p>Version 1.0.0 will reference the state of the framework at the initial release of IRIS Web into production.</p>

<h4 class="heading--label">Major version X (X.y.z | X > 0)</h4>
<p>MUST be incremented if any backwards incompatible changes are introduced. It MAY also include minor and patch level changes.</p>
	
<p><strong>Patch and minor version MUST be reset to 0 when major version is incremented.</strong></p>

<h4 class="heading--label">Minor version Y (x.Y.z | x > 0)</h4>
<p>MUST be incremented if new, backwards compatible functionality is introduced. It MUST be incremented if any functionality is marked as deprecated.</p>
	
<p>It MAY be incremented if substantial new functionality or improvements are introduced within the private code. It MAY include patch level changes.</p>
	
<p><strong>Patch version MUST be reset to 0 when minor version is incremented.</strong></p>

<h4 class="heading--label">Patch version Z (x.y.Z | x > 0)</h4>
<p>MUST be incremented if only backwards compatible bug fixes are introduced. A bug fix is defined as an internal change that fixes incorrect behavior.</p>

<h4 class="heading--label">Handling Depricated Functionality</h4>
<p>When functionality within the framework is slated for deprication, developers can expect:</p>

<ol>
	<li>Update to the documentation identifying the change.
	<li>Issue of a new minor release with the deprecation in place.
</ol>
	
<p>Before functionality is completely removed in a new major release there should be at least one minor release that contains the deprecation so that developers can smoothly transition.</p>

</section>
    
<?php $page->footer(); ?>
    
